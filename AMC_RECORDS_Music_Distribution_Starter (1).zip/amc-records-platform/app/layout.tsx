import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "AMC RECORDS | Music Distribution",
  description: "Artist portal and music distribution administration for AMC RECORDS."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
