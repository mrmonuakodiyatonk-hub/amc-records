-- AMC RECORDS schema — run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.account_role as enum ('artist','admin');
create type public.release_status as enum ('pending_review','changes_requested','approved','rejected','delivered');
create type public.royalty_status as enum ('pending','approved','paid');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  full_name text,
  role public.account_role not null default 'artist',
  created_at timestamptz not null default now()
);

create function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id,email,full_name,role)
  values (new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','Artist'),'artist')
  on conflict (id) do update set email=excluded.email;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create table public.releases (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  primary_artist text not null check (char_length(primary_artist) between 1 and 200),
  release_type text not null default 'single' check (release_type in ('single','EP','album')),
  release_date date,
  language text,
  genre text,
  isrc text,
  upc text,
  audio_path text,
  artwork_path text,
  status public.release_status not null default 'pending_review',
  admin_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index releases_artist_created_idx on public.releases(artist_id, created_at desc);

create table public.royalty_entries (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.profiles(id) on delete cascade,
  release_id uuid references public.releases(id) on delete set null,
  period_start date not null,
  period_end date not null check (period_end >= period_start),
  source text not null default 'manual',
  currency char(3) not null default 'INR',
  amount numeric(14,2) not null check (amount >= 0),
  status public.royalty_status not null default 'pending',
  reference text,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index royalty_artist_period_idx on public.royalty_entries(artist_id, period_start desc);

create table public.distribution_events (
  id uuid primary key default gen_random_uuid(),
  release_id uuid not null references public.releases(id) on delete cascade,
  provider text not null,
  external_release_id text,
  status text not null,
  message text,
  synced_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.releases enable row level security;
alter table public.royalty_entries enable row level security;
alter table public.distribution_events enable row level security;
alter table public.audit_log enable row level security;

-- Profiles: artists may read/update their own profile, but cannot change their role.
create policy "profile read self or admin" on public.profiles for select
  using (id = auth.uid() or public.is_admin());
create policy "profile update self or admin" on public.profiles for update
  using (id = auth.uid() or public.is_admin())
  with check ((id = auth.uid() and role = (select p.role from public.profiles p where p.id = auth.uid())) or public.is_admin());

-- Releases: artist sees and creates own; admins can review all.
create policy "release read owner or admin" on public.releases for select
  using (artist_id = auth.uid() or public.is_admin());
create policy "release insert as owner" on public.releases for insert
  with check (artist_id = auth.uid() and status = 'pending_review');
create policy "release update owner or admin" on public.releases for update
  using (artist_id = auth.uid() or public.is_admin())
  with check (artist_id = auth.uid() or public.is_admin());

-- Royalty rows: artist read-only for own rows; admin manages ledger.
create policy "royalty read owner or admin" on public.royalty_entries for select
  using (artist_id = auth.uid() or public.is_admin());
create policy "royalty insert admin only" on public.royalty_entries for insert
  with check (public.is_admin() and (created_by = auth.uid() or created_by is null));
create policy "royalty update admin only" on public.royalty_entries for update
  using (public.is_admin()) with check (public.is_admin());
create policy "royalty delete admin only" on public.royalty_entries for delete
  using (public.is_admin());

create policy "distribution events admin read" on public.distribution_events for select
  using (public.is_admin() or exists(select 1 from public.releases r where r.id = release_id and r.artist_id = auth.uid()));
create policy "distribution events admin insert" on public.distribution_events for insert
  with check (public.is_admin());
create policy "audit log admin read" on public.audit_log for select using (public.is_admin());
create policy "audit log admin insert" on public.audit_log for insert with check (actor_id = auth.uid() and public.is_admin());

-- Keep role assignment out of public signup metadata. Admins are promoted manually by project owner.
grant usage on schema public to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update on public.releases to authenticated;
grant select, insert, update, delete on public.royalty_entries to authenticated;
grant select, insert on public.distribution_events to authenticated;
grant select, insert on public.audit_log to authenticated;
