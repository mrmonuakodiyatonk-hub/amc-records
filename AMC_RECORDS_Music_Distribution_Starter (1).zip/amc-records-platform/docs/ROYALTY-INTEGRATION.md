# Royalty automation integration plan

The app supports manual royalty entries now. Automated royalty import is intentionally not faked: it requires a signed contract and API access from the chosen distributor / label-services provider.

## Provider adapter contract
Create a server-only adapter that:
1. Fetches reports with provider credentials held in server environment variables (never `NEXT_PUBLIC_`).
2. Verifies webhook signatures where supported.
3. Normalizes provider rows into: provider, external report ID, release identifier (ISRC/UPC), territory, platform, period, currency, gross amount, deductions, net amount.
4. Maps the report's ISRC/UPC to `releases`, then maps ownership/splits to the right artist account.
5. Uses idempotency keys so importing the same statement twice does not double-credit royalties.
6. Stores raw report references and import job status; keeps an audit log.
7. Requires admin reconciliation before balances become payable.

## Important
Streaming royalties are not a single universal public API. Availability and permitted usage vary by distributor/platform, and access may require commercial approval. Do not calculate payouts from stream counts alone without an authoritative rate/report.
