# Deployment guide

## Supabase
1. Create a project and run `supabase/schema.sql`.
2. In Auth settings, enable email/password and configure email confirmation.
3. Set Site URL and redirect URLs for localhost and your eventual production domain.
4. Create a private Storage bucket named `release-assets`; enforce allowed MIME types and file-size limits.
5. For production, add storage object policies so artists can upload/read only their own path and admins can review files. Do not make audio files public by default.

## Local development
- Install Node.js 20+
- `npm install`
- Copy `.env.example` to `.env.local` and fill in Supabase project URL + anon key
- `npm run dev`

## Vercel
- Push to GitHub and import into Vercel
- Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- Deploy and set production URL in Supabase Auth settings
- Verify RLS using two artist accounts and one admin account

## Domain
Buy a domain from a registrar of your choice, then add it to Vercel and follow its DNS instructions. Domain purchase is not included in this project.

## Before accepting real artists
This is a starter implementation, not a certified distribution service. Add server-side audited admin actions, password reset, email verification UX, secure file upload with signed URLs, file scanning/validation, legal agreements, takedown process, payout integrations, and provider-specific distribution adapters.
